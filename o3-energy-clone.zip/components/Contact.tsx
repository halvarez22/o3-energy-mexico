
import React from 'react';

const Contact: React.FC = () => {
  return (
    <section id="contact" className="py-20 md:py-32 bg-[#121212]">
      <div className="container mx-auto px-6">
        <div className="text-center">
            <h2 className="text-4xl md:text-5xl font-bold mb-16">Contacto</h2>
        </div>
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div>
              <h3 className="text-2xl font-bold text-[#A4E834]">Oficina Central</h3>
              <p className="text-gray-300 mt-2 text-lg">
                Av. de la Reforma 222, Piso 10<br/>
                Col. Juárez, Cuauhtémoc<br/>
                06600, Ciudad de México, México
              </p>
            </div>
            <div>
              <h3 className="text-2xl font-bold text-[#A4E834]">Información</h3>
              <p className="text-gray-300 mt-2 text-lg">
                <a href="mailto:info@o3energy.com" className="hover:text-[#A4E834] transition-colors">info@o3energy.com</a>
              </p>
              <p className="text-gray-300 text-lg">
                <a href="tel:+525512345678" className="hover:text-[#A4E834] transition-colors">+52 (55) 1234 5678</a>
              </p>
            </div>
          </div>
          <div>
              <div className="aspect-w-16 aspect-h-9 rounded-lg overflow-hidden shadow-2xl">
                   <img src="https://picsum.photos/seed/map/800/450" alt="Map placeholder" className="w-full h-full object-cover" />
              </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
