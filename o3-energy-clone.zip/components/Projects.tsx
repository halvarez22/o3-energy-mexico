
import React from 'react';
import { PROJECTS_DATA } from '../constants';

const Projects: React.FC = () => {
  return (
    <section id="projects" className="py-20 md:py-32 bg-[#121212]">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-4xl md:text-5xl font-bold mb-16">Nuestros Proyectos</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {PROJECTS_DATA.map((project, index) => (
            <div key={index} className="bg-[#1a1a1a] rounded-lg overflow-hidden group">
              <img src={project.image} alt={project.name} className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300" />
              <div className="p-6">
                <h3 className="text-xl font-bold text-[#A4E834]">{project.name}</h3>
                <p className="text-gray-400 mt-1">{project.location}</p>
                <p className="mt-2 text-white font-semibold">{project.capacity}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;
