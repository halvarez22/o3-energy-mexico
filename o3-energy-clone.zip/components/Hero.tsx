
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section id="home" className="h-screen flex items-center justify-center text-center bg-cover bg-center" style={{ backgroundImage: "url('https://picsum.photos/seed/solar-panels/1920/1080')" }}>
      <div className="absolute inset-0 bg-black/60"></div>
      <div className="relative z-10 px-6">
        <h1 className="text-5xl md:text-7xl lg:text-8xl font-black uppercase tracking-tight leading-tight">
          Liderando la transición <br />
          <span className="text-[#A4E834]">energética en México</span>
        </h1>
        <p className="mt-6 max-w-3xl mx-auto text-lg md:text-xl text-gray-200">
          Desarrollamos, construimos y operamos proyectos de energía renovable a gran escala.
        </p>
        <a href="#about" className="mt-8 inline-block bg-[#A4E834] text-black font-bold py-3 px-8 rounded-full uppercase tracking-wider hover:bg-white transition-all duration-300 transform hover:scale-105">
          Conócenos
        </a>
      </div>
    </section>
  );
};

export default Hero;
